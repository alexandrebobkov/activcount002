package com.example.activcount_002;

import android.widget.TextView;

public class MainData
{
    private static float assets_current, assets_supplies, assets_total;
    private static float liabilities_current, liabilities_long_term, liabilities_total;

    public MainData()
    {
        assets_current            = 0;
        assets_supplies           = 0;
        assets_total              = 0;
        liabilities_current       = 0;
        liabilities_long_term     = 0;
        liabilities_total         = 0;

    }

    //public void setAssetsCurrent(TextView tv)   {   assets_current = ""+tv.getText();     }
    public void setAssetsCurrent(Float num)   {   assets_current = num;     }
    public void setAssetsSupplies(Float num)  {   assets_supplies = num;    }
    public void setAssetsTotal(Float num)     {   assets_total = num;         }
    public float getAssetsCurrent ()           {   return assets_current;                  }
    public float getAssetsSupplies ()          {   return assets_supplies;                 }
    public float getAssetsTotal ()             {   return assets_total;                    }

}
