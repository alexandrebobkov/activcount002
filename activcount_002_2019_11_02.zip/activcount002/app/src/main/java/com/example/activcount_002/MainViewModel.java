/**
 *
 *  Date Created:       October 31, 2019
 *  Last time updated:  October 31, 2019
 *  Revision:           2
 *
 *  Author:             Alexandre Bobkov
 *  Company:            Alexandre Comptabilite Specialise Ltee.
 *
 *  Objective:          main class for handling all UX items (textboxes, buttons, etc).
 *
 **/
package com.example.activcount_002;

import android.widget.TextView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel
{
    private static String status_msg         = "initial value";         // define static variable: one for all instances.
    private static String home_status_msg    = "initial home status";   // define static variable: one for all instances.

    private static String str_assets_current    = "20.25";
    private static String str_assets_supplies   = "10.15";
    private static String str_assets_total      = "35.75";
    private static String liabilities_current   = "0.00";
    private static String liabilities_long_term = "0.00";
    private static String liabilities_total     = "0.00";
    private MutableLiveData<String> statusText;
    private MutableLiveData<String> homeStatusText;
    private MutableLiveData<String> assetsCurrentText;
    private MutableLiveData<String> assetsSuppliesText;
    private MutableLiveData<String> assetsTotalText;

    public MainViewModel()
    {
        statusText      = new MutableLiveData<>();
        homeStatusText  = new MutableLiveData<>();
        assetsCurrentText  = new MutableLiveData<>();
        assetsSuppliesText  = new MutableLiveData<>();
        assetsTotalText  = new MutableLiveData<>();

        statusText.setValue(status_msg);
        homeStatusText.setValue(home_status_msg);

        assetsCurrentText.setValue(str_assets_current);
        assetsSuppliesText.setValue(str_assets_supplies);
        assetsTotalText.setValue(str_assets_total);
    }

    public void setStatus_msg(String s)                 {   status_msg = s;             }
    public void setHomeStatus_msg(String s)             {   home_status_msg = s;        }

    public void setAssetsCurrent(TextView tv)           {   str_assets_current = ""+tv.getText();       }
    public void setAssetsSupplies(TextView tv)          {   str_assets_supplies = ""+tv.getText();      }
    public void setAssetsTotal(TextView tv)             {   str_assets_total = ""+tv.getText();         }

    public String getAssetsCurrent()                    {   return str_assets_current;  }
    public String getAssetsSupplies()                   {   return str_assets_supplies; }
    public String getAssetsTotal()                      {   return str_assets_total;    }

    public String get_home_status_msg()                 {   return home_status_msg;     }

    public LiveData<String> getStatus_msg()             {   return statusText;          }
    public LiveData<String> getAssetsCurrentText()      {   return assetsCurrentText;   }
    public LiveData<String> getAssetsSuppliesText()     {   return assetsSuppliesText;  }
    public LiveData<String> getAssetsTotalText()        {   return assetsTotalText;     }
}
